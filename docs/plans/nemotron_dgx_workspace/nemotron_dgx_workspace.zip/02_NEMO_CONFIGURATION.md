# Step 2: Config Files
### env.toml
```toml
[wandb]
project = "nemotron3-nano-tuning"
entity = "YOUR-WANDB-USERNAME"

[DGX-SPARK-LOCAL]
executor = "local"
gpus_per_node = 1
mounts = ["/home:/home", "/data:/data"]
```

### nemotron_sft_config.yaml
```yaml
model:
  tensor_model_parallel_size: 1
  pipeline_model_parallel_size: 1
  num_moe_experts: 128
  moe_router_topk: 6
  pre_tokenized_dataset: True
  data:
    train_ds:
      file_names: ["/data/nemotron_pretokenized_corpus_cleaned.jsonl"]
      max_seq_length: 8192
  micro_batch_size: 1
  global_batch_size: 4
  seq_length: 8192
  bf16: True
  activations_checkpoint_method: "uniform"
  activations_checkpoint_granularity: "selective"
  peft:
    peft_scheme: "lora"
    lora_tuning:
      r: 8
      adapter_alpha: 16
      lora_dropout: 0.0
      target_modules: ["q_proj", "k_proj", "v_proj", "out_proj", "in_proj"]
exp_manager:
  exp_dir: "/data/nemotron_runs"
  name: "nemotron3-nano-reasoning-lora"
  create_wandb_logger: True
  wandb_logger_kwargs:
    project: "nemotron3-nano-tuning"
    entity: "YOUR-WANDB-USERNAME"
```